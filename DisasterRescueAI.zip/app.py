from flask import Flask, render_template, jsonify, request
from disaster_backend import DisasterBackend

app = Flask(__name__)
system = DisasterBackend()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/state")
def state():
    return jsonify(system.state())

@app.post("/api/action")
def action():
    data = request.get_json(silent=True) or {}
    action = data.get("action", "")
    result = system.action(action)
    return jsonify(result)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
