const canvas = document.getElementById("map");
const ctx = canvas.getContext("2d");
const COLS=48, ROWS=32;
const CW=canvas.width/COLS, CH=canvas.height/ROWS;
let state=null;

function clock(){
  const now=new Date();
  document.getElementById("clock").textContent=now.toLocaleTimeString("en-IN",{hour12:false});
  document.getElementById("date").textContent=now.toLocaleDateString("en-IN",{weekday:"short",day:"2-digit",month:"short",year:"numeric"});
}
setInterval(clock,1000); clock();

async function action(a){
  await fetch("/api/action",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:a})});
  await refresh();
}
async function refresh(){
  const r=await fetch("/api/state");
  state=await r.json();
  render();
}
function cell(x,y){return [x*CW,y*CH]}
function calculateRouteRisk(){
  if(!state||!state.robots)return "LOW";
  const hazards=new Set((state.hazards||[]).map(p=>p.join(",")));
  let hazardSteps=0;
  for(const r of state.robots){
    for(const p of (r.path||[])) if(hazards.has(p.join(","))) hazardSteps++;
  }
  if(hazardSteps>=12)return "HIGH";
  if(hazardSteps>=4)return "MEDIUM";
  return "LOW";
}
function renderSurvivorIntel(){
  const box=document.getElementById("survivorIntel");
  if(!box||!state)return;
  box.innerHTML=(state.survivors||[]).map(s=>{
    const pct=Math.max(0,Math.min(100,s.urgency_score||0));
    const condition=s.condition||s.severity;
    const assigned=s.assigned_robot||"UNASSIGNED";
    const support=s.support_robot?`<span>SUPPORT: ${s.support_robot}</span>`:"";
    return `<div class="survivor-row"><div class="survivor-top"><span>${s.id}</span><strong>${condition}</strong></div><div class="survivor-meta"><span>Urgency ${pct}/100</span><span>${assigned}</span></div><div class="urgency-bar"><i style="width:${pct}%"></i></div>${support}${s.treatment_required?'<div class="treatment">MEDICAL PRIORITY</div>':''}</div>`;
  }).join("");
}
function renderAnalytics(){
  const a=state.analytics||{};
  document.getElementById("missionTime").textContent=a.mission_time||"00:00";
  document.getElementById("aiDecisions").textContent=a.ai_decisions??0;
  document.getElementById("hazardAvoidances").textContent=a.hazard_avoidances??0;
  document.getElementById("coordEvents").textContent=a.coordination_events??0;
  document.getElementById("conflictResolved").textContent=a.route_conflicts_resolved??0;
  document.getElementById("robotMoves").textContent=a.robot_moves??0;
  const timeline=document.getElementById("timeline");
  if(!timeline)return;
  timeline.innerHTML=(state.timeline||[]).slice().reverse().slice(0,12).map(e=>{
    const t=(e.t??0).toFixed(1).padStart(4,"0");
    return `<div class="timeline-item"><span class="timeline-time">${t}s</span><span class="timeline-dot"></span><span class="timeline-text">${e.message}</span></div>`;
  }).join("") || '<div class="timeline-empty">Mission timeline will appear when the operation starts.</div>';
}
function renderCoordination(){
  const c=state.coordination||{};
  document.getElementById("coordLink").textContent=c.active?"ONLINE":"OFFLINE";
  document.getElementById("coordCycles").textContent=c.cycles??0;
  document.getElementById("routeConflicts").textContent=c.route_conflicts??0;
  document.getElementById("supportRequests").textContent=(c.support_requests||[]).length;
  document.getElementById("fleetDecision").textContent=c.fleet_decision||"Awaiting survivor intelligence";
  document.getElementById("comms").innerHTML=(c.communications||[]).slice().reverse().map(e=>`<div class="comm">› ${e}</div>`).join("");
}
function render(){
  if(!state)return;
  document.getElementById("disasterTitle").textContent=state.disaster.toUpperCase();
  document.getElementById("missionStatus").textContent=state.running?"AUTONOMOUS OPERATION ACTIVE":"STANDBY / PAUSED";
  const reached=state.survivors.filter(s=>s.reached).length;
  const detected=state.survivors.filter(s=>s.detected).length;
  document.getElementById("survivors").textContent=`${reached}/3`;
  document.getElementById("detected").textContent=`${detected}/3`;
  document.getElementById("mapped").textContent=state.mapped;
  const profile=state.disaster_profile||{};
  const strategy=state.ai_strategy||state.ai_last_decision||"Awaiting reconnaissance";
  document.getElementById("strategyChip").textContent=strategy;
  document.getElementById("aiMode").textContent=state.ai_mode||"ADAPTIVE";
  document.getElementById("aiStrategy").textContent=strategy.replace(/^AI PROFILE:\s*/i,"");
  document.getElementById("hazardType").textContent=state.hazard_type||profile.hazard_type||"--";
  document.getElementById("hazardAlerts").textContent=state.hazard_alerts??0;
  document.getElementById("aiDecision").textContent=state.ai_last_decision||"Awaiting reconnaissance";
  document.getElementById("routeRisk").textContent=calculateRouteRisk();
  document.getElementById("missionResult").textContent=state.mission_complete?"SUCCESS":(state.running?"ACTIVE":"READY");
  renderSurvivorIntel();
  renderCoordination();
  renderAnalytics();
  document.getElementById("fleet").innerHTML=state.robots.map(r=>{
    const comm=r.communication||"STANDBY";
    const support=r.assisting?`<div class="robot-support">ASSISTING: ${r.assisting}</div>`:"";
    return `<div class="robot"><div class="robot-head"><span style="color:${r.color}">${r.name}</span><span>${r.status}</span></div><div class="robot-role">${r.role}</div><div class="robot-target">TARGET: ${targetName(r.target)}</div><div class="robot-comm">COMMS: ${comm}</div>${support}</div>`;
  }).join("");
  document.getElementById("log").innerHTML=state.events.slice().reverse().map(e=>`<div class="log">› ${e}</div>`).join("");
  draw();
}
function targetName(target){
  if(!target)return "--";
  const survivor=state.survivors.find(s=>s.x===target[0]&&s.y===target[1]);
  return survivor?survivor.id:`${target[0]},${target[1]}`;
}
function draw(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle="#101e2c";ctx.fillRect(0,0,canvas.width,canvas.height);
  const scanned=new Set(state.drone.scanned.map(p=>p.join(",")));
  for(let y=0;y<ROWS;y++)for(let x=0;x<COLS;x++){
    const k=x+","+y;
    ctx.fillStyle=scanned.has(k)?"#173440":"#101e2c";
    ctx.fillRect(x*CW,y*CH,CW-1,CH-1);
  }
  for(const p of(state.hazards||[])){
    ctx.fillStyle="#4b3430";
    ctx.fillRect(p[0]*CW+3,p[1]*CH+3,CW-7,CH-7);
  }
  for(const p of state.obstacles){
    ctx.fillStyle="#71483f";
    ctx.fillRect(p[0]*CW+1,p[1]*CH+1,CW-3,CH-3);
  }
  for(const r of state.robots){
    if(!r.path||!r.path.length)continue;
    ctx.strokeStyle=r.color;ctx.globalAlpha=.28;ctx.lineWidth=1.6;ctx.beginPath();
    for(let i=0;i<r.path.length;i++){
      let[x,y]=cell(r.path[i][0],r.path[i][1]);
      if(i===0)ctx.moveTo(x+CW/2,y+CH/2);else ctx.lineTo(x+CW/2,y+CH/2);
    }
    ctx.stroke();ctx.globalAlpha=1;
    const reserved=new Set((r.reserved_cells||[]).map(p=>p.join(",")));
    ctx.fillStyle=r.color;ctx.globalAlpha=.16;
    for(const p of reserved) { const [x,y]=p.split(",").map(Number);ctx.fillRect(x*CW+5,y*CH+5,CW-10,CH-10); }
    ctx.globalAlpha=1;
  }
  for(const s of state.survivors){
    const[x,y]=cell(s.x,s.y);
    ctx.fillStyle=s.reached?"#69cd91":(s.detected?"#f5c44e":"#8a7a45");
    ctx.beginPath();ctx.arc(x+CW/2,y+CH/2,7,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#cdd8e4";ctx.font="9px Consolas";ctx.fillText(s.id.split("-")[1],x+CW+2,y+CH/2+3);
  }
  for(const r of state.robots){
    const[x,y]=cell(r.x,r.y);ctx.fillStyle=r.color;ctx.fillRect(x+3,y+3,CW-6,CH-6);
    ctx.fillStyle="#061018";ctx.font="bold 8px Consolas";ctx.fillText(r.name.split("-")[0][0],x+7,y+13);
  }
  const d=state.drone;
  if(d.active){const[x,y]=cell(d.x,d.y);ctx.strokeStyle="#5fbede";ctx.lineWidth=2;ctx.beginPath();ctx.arc(x+CW/2,y+CH/2,8,0,Math.PI*2);ctx.stroke();}
  ctx.strokeStyle="#1d2d3c";ctx.lineWidth=.5;
  for(let x=0;x<=COLS;x+=4){ctx.beginPath();ctx.moveTo(x*CW,0);ctx.lineTo(x*CW,canvas.height);ctx.stroke()}
  for(let y=0;y<=ROWS;y+=4){ctx.beginPath();ctx.moveTo(0,y*CH);ctx.lineTo(canvas.width,y*CH);ctx.stroke()}
}
setInterval(refresh,120);refresh();
document.addEventListener("keydown",e=>{
  const key=e.key.toLowerCase();
  if(key===" "){e.preventDefault();action("mission")}
  if(key==="d")action("drone");
  if(key==="c")action("vision");
  if(key==="a")action("ai");
  if(key==="t")action("stress_test");
  if(key==="r")action("reset");
  if(["1","2","3","4"].includes(key))action(["Earthquake","Flood","Fire","Landslide"][Number(key)-1]);
});
