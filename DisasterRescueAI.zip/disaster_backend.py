import random
import heapq
import time

COLS, ROWS = 48, 32


class Robot:
    def __init__(self, name, role, start, color):
        self.name = name
        self.role = role
        self.start = start
        self.pos = start
        self.target = start
        self.color = color
        self.path = []
        self.path_index = 0
        self.status = "STANDBY"
        self.last_move = 0.0
        self.mission_count = 0
        self.communication = "STANDBY"
        self.support_request = None
        self.assisting = None
        self.reserved_cells = []


class DisasterBackend:
    """
    DisasterRescueAI V8 backend.

    V8 adds an explainable multi-robot coordination layer:
        Recon -> Detection -> Dynamic Patient Intelligence
        -> AI Allocation -> Fleet Coordination -> Conflict-aware A* Routing
        -> Hazard Response -> Rescue

    This is still a local simulation. The coordination engine is deterministic
    and rule-based so every decision can be explained in the command center.
    """

    def __init__(self):
        self.disaster = "Earthquake"
        self.reset()

    # ---------------------------------------------------------
    # WORLD INITIALIZATION
    # ---------------------------------------------------------

    def reset(self):
        seeds = {
            "Earthquake": 21,
            "Flood": 33,
            "Fire": 47,
            "Landslide": 61,
        }

        random.seed(seeds[self.disaster])

        self.obstacles = {
            (random.randrange(COLS), random.randrange(ROWS))
            for _ in range(165)
        }

        starts = [
            (2, 2),
            (2, ROWS - 4),
            (COLS - 4, 2),
        ]

        goals = [
            (COLS - 5, ROWS - 5),
            (COLS - 6, 5),
            (COLS // 2, ROWS // 2 + 7),
        ]

        for point in starts + goals:
            for dx in range(-2, 3):
                for dy in range(-2, 3):
                    self.obstacles.discard(
                        (point[0] + dx, point[1] + dy)
                    )

        self.robots = [
            Robot(
                "RESCUE-01",
                "SEARCH & RESCUE",
                starts[0],
                "#35d0a2",
            ),
            Robot(
                "MEDICAL-01",
                "MEDICAL SUPPORT",
                starts[1],
                "#65a0eb",
            ),
            Robot(
                "SUPPLY-01",
                "EMERGENCY SUPPLY",
                starts[2],
                "#c47dde",
            ),
        ]

        self.survivors = [
            {
                "id": "SURVIVOR-01",
                "pos": goals[0],
                "severity": "CRITICAL",
                "reached": False,
                "detected": False,
                "assigned_robot": None,
                "support_robot": None,
                "condition": "CRITICAL",
                "urgency_score": 88,
                "treatment_required": True,
                "last_condition_update": 0.0,
            },
            {
                "id": "SURVIVOR-02",
                "pos": goals[1],
                "severity": "HIGH",
                "reached": False,
                "detected": False,
                "assigned_robot": None,
                "support_robot": None,
                "condition": "SERIOUS",
                "urgency_score": 68,
                "treatment_required": True,
                "last_condition_update": 0.0,
            },
            {
                "id": "SURVIVOR-03",
                "pos": goals[2],
                "severity": "MEDIUM",
                "reached": False,
                "detected": False,
                "assigned_robot": None,
                "support_robot": None,
                "condition": "STABLE",
                "urgency_score": 42,
                "treatment_required": False,
                "last_condition_update": 0.0,
            },
        ]

        self.hazards = self.generate_hazards()
        self.profile = self.disaster_profile()

        self.events = [
            "SYSTEM READY",
            "AI mission planner initialized",
            "3 response units standing by",
        ]

        self.drone = {
            "x": COLS // 2,
            "y": 2,
            "active": False,
            "scanned": set(),
            "scan_progress": 0,
            "detections": set(),
        }

        self.vision_active = False
        self.running = False
        self.mission_complete = False
        self.ai_mode = "ADAPTIVE"
        self.ai_last_decision = "Awaiting reconnaissance"
        self.last_ai_replan = 0.0
        self.hazard_alerts = 0
        self.dynamic_hazards = set()

        # V8 coordination state.
        self.coordination_active = True
        self.communication_log = [
            "FLEET LINK ONLINE",
            "INTER-ROBOT COORDINATION READY",
        ]
        self.support_requests = []
        self.route_conflicts = 0
        self.coordination_cycles = 0
        self.last_coordination = 0.0
        self.fleet_decision = "Awaiting survivor intelligence"

        # V9 mission analytics + replay timeline.
        self.mission_start_time = None
        self.mission_end_time = None
        self.analytics = {
            "ai_decisions": 0,
            "hazard_avoidances": 0,
            "coordination_events": 0,
            "route_conflicts_resolved": 0,
            "rescues": 0,
            "robot_moves": 0,
            "replans": 0,
        }
        self.timeline = []

        self.prepare_routes()
        self.log(self.disaster_message())

    def disaster_profile(self):
        profiles = {
            "Earthquake": {
                "hazard_type": "RUBBLE",
                "hazard_density": 28,
                "hazard_penalty": 8,
                "priority_order": ["CRITICAL", "HIGH", "MEDIUM"],
                "recommended_roles": {
                    "CRITICAL": "MEDICAL SUPPORT",
                    "HIGH": "SEARCH & RESCUE",
                    "MEDIUM": "EMERGENCY SUPPLY",
                },
            },
            "Flood": {
                "hazard_type": "FLOODED ZONE",
                "hazard_density": 35,
                "hazard_penalty": 12,
                "priority_order": ["CRITICAL", "HIGH", "MEDIUM"],
                "recommended_roles": {
                    "CRITICAL": "SEARCH & RESCUE",
                    "HIGH": "EMERGENCY SUPPLY",
                    "MEDIUM": "MEDICAL SUPPORT",
                },
            },
            "Fire": {
                "hazard_type": "FIRE ZONE",
                "hazard_density": 32,
                "hazard_penalty": 16,
                "priority_order": ["CRITICAL", "HIGH", "MEDIUM"],
                "recommended_roles": {
                    "CRITICAL": "SEARCH & RESCUE",
                    "HIGH": "MEDICAL SUPPORT",
                    "MEDIUM": "EMERGENCY SUPPLY",
                },
            },
            "Landslide": {
                "hazard_type": "UNSTABLE SLOPE",
                "hazard_density": 26,
                "hazard_penalty": 14,
                "priority_order": ["CRITICAL", "HIGH", "MEDIUM"],
                "recommended_roles": {
                    "CRITICAL": "SEARCH & RESCUE",
                    "HIGH": "MEDICAL SUPPORT",
                    "MEDIUM": "EMERGENCY SUPPLY",
                },
            },
        }
        return profiles[self.disaster]

    def generate_hazards(self):
        profile = self.disaster_profile()
        random.seed(sum(ord(c) for c in self.disaster) + 900)

        hazards = set()
        protected = [
            robot.start for robot in self.robots
        ] + [
            survivor["pos"] for survivor in self.survivors
        ]

        while len(hazards) < profile["hazard_density"]:
            point = (
                random.randrange(1, COLS - 1),
                random.randrange(1, ROWS - 1),
            )

            if point in self.obstacles:
                continue

            if any(
                abs(point[0] - p[0]) <= 2
                and abs(point[1] - p[1]) <= 2
                for p in protected
            ):
                continue

            hazards.add(point)

        return hazards

    def disaster_response_score(self, robot, survivor, route):
        profile = self.disaster_profile()
        severity_value = {
            "CRITICAL": 100,
            "HIGH": 70,
            "MEDIUM": 40,
        }

        score = survivor.get(
            "urgency_score",
            severity_value[survivor["severity"]],
        ) * 2
        score -= max(0, len(route) - 1)

        recommended = profile["recommended_roles"].get(
            survivor["severity"]
        )
        if robot.role == recommended:
            score += 45

        if self.disaster == "Flood" and robot.role == "EMERGENCY SUPPLY":
            score += 12
        elif self.disaster == "Fire" and robot.role == "SEARCH & RESCUE":
            score += 18
        elif self.disaster == "Earthquake" and robot.role == "MEDICAL SUPPORT":
            score += 20
        elif self.disaster == "Landslide" and robot.role == "SEARCH & RESCUE":
            score += 15

        hazard_steps = sum(point in self.hazards for point in route)
        score -= hazard_steps * profile["hazard_penalty"]

        # Prefer paths that don't collide with another robot's near-term route.
        score -= self.route_conflict_cost(robot, route) * 10
        return score

    def disaster_message(self):
        messages = {
            "Earthquake": "AI PROFILE: RUBBLE NAVIGATION MODE",
            "Flood": "AI PROFILE: FLOOD-SAFE ROUTING MODE",
            "Fire": "AI PROFILE: FIRE-AVOIDANCE MODE",
            "Landslide": "AI PROFILE: SLOPE-STABILITY MODE",
        }
        return messages[self.disaster]

    # ---------------------------------------------------------
    # V9 MISSION ANALYTICS / REPLAY
    # ---------------------------------------------------------

    def record_timeline(self, event_type, message, robot=None, survivor=None):
        elapsed = 0.0
        if self.mission_start_time is not None:
            elapsed = max(0.0, time.time() - self.mission_start_time)
        self.timeline.append({
            "t": round(elapsed, 1),
            "type": event_type,
            "message": message,
            "robot": robot,
            "survivor": survivor,
        })
        self.timeline = self.timeline[-60:]

    def mission_elapsed(self):
        if self.mission_start_time is None:
            return 0.0
        end = self.mission_end_time if self.mission_end_time is not None else time.time()
        return max(0.0, end - self.mission_start_time)

    def analytics_snapshot(self):
        reached = sum(s["reached"] for s in self.survivors)
        detected = sum(s["detected"] for s in self.survivors)
        return {
            "elapsed_seconds": round(self.mission_elapsed(), 1),
            "mission_time": self.format_duration(self.mission_elapsed()),
            "survivors_rescued": reached,
            "survivors_total": len(self.survivors),
            "detected": detected,
            "robots_deployed": sum(1 for r in self.robots if r.mission_count > 0 or r.status in {"EN ROUTE", "TARGET REACHED", "PAUSED", "HAZARD ZONE"}),
            "routes_completed": sum(1 for r in self.robots if r.mission_count > 0),
            **self.analytics,
        }

    @staticmethod
    def format_duration(seconds):
        seconds = int(max(0, seconds))
        return f"{seconds // 60:02d}:{seconds % 60:02d}"

    # ---------------------------------------------------------
    # LOGGING / COMMUNICATION
    # ---------------------------------------------------------

    def log(self, text):
        if not self.events or self.events[-1] != text:
            self.events.append(text)
        self.events = self.events[-8:]

        upper = text.upper()
        if any(key in upper for key in ("AI ADAPTIVE", "AI REALLOCATION", "AI REROUTE", "AI ALERT")):
            self.analytics["ai_decisions"] += 1
        if "REROUTE" in upper:
            self.analytics["hazard_avoidances"] += 1
        if "CONFLICT" in upper or "SUPPORT" in upper or "COMMS:" in upper:
            self.analytics["coordination_events"] += 1
        self.record_timeline("event", text)

    def communicate(self, sender, message):
        entry = f"{sender} > {message}"
        self.communication_log.append(entry)
        self.communication_log = self.communication_log[-8:]
        self.log(f"COMMS: {entry}")

    # ---------------------------------------------------------
    # ROUTE CONFLICT / COORDINATION
    # ---------------------------------------------------------

    def route_conflict_cost(self, robot, route):
        if not route:
            return 0

        future = set(route[:10])
        cost = 0
        for other in self.robots:
            if other is robot or not other.path:
                continue
            other_future = set(other.path[other.path_index:other.path_index + 10])
            cost += len(future & other_future)
        return cost

    def reserve_routes(self):
        for robot in self.robots:
            robot.reserved_cells = robot.path[robot.path_index:robot.path_index + 10]

    def detect_route_conflicts(self):
        conflicts = []
        for i, first in enumerate(self.robots):
            a = set(first.reserved_cells)
            if not a:
                continue
            for second in self.robots[i + 1:]:
                b = set(second.reserved_cells)
                overlap = a & b
                if overlap:
                    conflicts.append((first, second, overlap))
        return conflicts

    def resolve_route_conflicts(self):
        self.reserve_routes()
        conflicts = self.detect_route_conflicts()
        if not conflicts:
            return

        for first, second, overlap in conflicts:
            self.route_conflicts += 1
            self.analytics["route_conflicts_resolved"] += 1

            # The robot with the more urgent patient gets right-of-way.
            first_survivor = self.survivor_for_robot(first)
            second_survivor = self.survivor_for_robot(second)

            first_score = first_survivor["urgency_score"] if first_survivor else 0
            second_score = second_survivor["urgency_score"] if second_survivor else 0

            lower = second if first_score >= second_score else first
            higher = first if lower is second else second

            alternate = self.astar(
                lower.pos,
                lower.target,
                blocked=set(higher.reserved_cells),
            )

            if alternate and alternate != lower.path:
                lower.path = alternate
                lower.path_index = 0
                lower.communication = f"YIELDING TO {higher.name}"
                higher.communication = "RIGHT OF WAY"
                self.communicate(
                    lower.name,
                    f"route conflict resolved; yielding to {higher.name}",
                )
            else:
                self.communicate(
                    higher.name,
                    f"holding priority for urgent target; {lower.name} reroute unavailable",
                )

        self.reserve_routes()

    def survivor_for_robot(self, robot):
        for survivor in self.survivors:
            if survivor.get("assigned_robot") == robot.name:
                return survivor
        return None

    def coordinate_fleet(self, reason="cycle"):
        """Coordinate assignments, support requests and route reservations."""
        if not self.coordination_active:
            return

        self.coordination_cycles += 1
        self.last_coordination = time.time()

        active = [
            survivor for survivor in self.survivors
            if survivor["detected"] and not survivor["reached"]
        ]

        if not active:
            self.fleet_decision = "Fleet synchronized; awaiting detected targets"
            for robot in self.robots:
                robot.communication = "STANDBY"
                robot.support_request = None
                robot.assisting = None
            return

        # Every active robot broadcasts its operational state.
        for robot in self.robots:
            if robot.pos != robot.target:
                robot.communication = "NAVIGATING"
            elif robot.target != robot.start:
                robot.communication = "AT TARGET"
            else:
                robot.communication = "STANDBY"

        # Critical patient escalation: request medical assistance if needed.
        critical = max(
            active,
            key=lambda s: s["urgency_score"],
            default=None,
        )

        if critical and critical["urgency_score"] >= 90:
            primary = self.robot_for_survivor(critical)
            medical = next(
                (r for r in self.robots if r.role == "MEDICAL SUPPORT"),
                None,
            )

            if medical and primary is not medical:
                medical_target = self.survivor_for_robot(medical)
                if medical_target is None or medical_target["urgency_score"] < critical["urgency_score"]:
                    if medical_target is not None:
                        medical_target["assigned_robot"] = None
                    old_target = critical.get("assigned_robot")
                    critical["assigned_robot"] = medical.name
                    medical.target = critical["pos"]
                    medical.path = self.astar(medical.pos, medical.target)
                    medical.path_index = 0
                    medical.status = "EN ROUTE" if self.running else "ASSIGNED"
                    medical.support_request = critical["id"]
                    medical.assisting = old_target
                    self.support_requests.append({
                        "survivor": critical["id"],
                        "requested_by": primary.name if primary else "AI",
                        "assigned_to": medical.name,
                        "reason": "critical condition",
                    })
                    self.support_requests = self.support_requests[-6:]
                    self.communicate(
                        medical.name,
                        f"medical priority accepted for {critical['id']}",
                    )
                    self.fleet_decision = (
                        f"{medical.name} prioritized for {critical['id']}"
                    )
                else:
                    medical.communication = f"MONITORING {critical['id']}"
                    self.fleet_decision = (
                        f"{medical.name} monitoring critical patient"
                    )

        # Critical cases also create a secondary support link. The support
        # robot keeps its own target but is now explicitly paired with the
        # medical unit, demonstrating cooperative fleet behavior.
        if critical and critical["urgency_score"] >= 95 and not critical.get("reached"):
            medical = next((r for r in self.robots if r.role == "MEDICAL SUPPORT"), None)
            primary = self.robot_for_survivor(critical)
            support = next(
                (r for r in self.robots if r is not medical and r is not primary),
                None,
            )
            if support:
                critical["support_robot"] = support.name
                support.assisting = medical.name if medical else "MEDICAL-01"
                support.communication = f"SUPPORTING {critical['id']}"
                already = any(
                    req.get("survivor") == critical["id"]
                    and req.get("type") == "SUPPORT LINK"
                    for req in self.support_requests
                )
                if not already:
                    self.support_requests.append({
                        "type": "SUPPORT LINK",
                        "survivor": critical["id"],
                        "requested_by": medical.name if medical else "AI-CENTER",
                        "assigned_to": support.name,
                        "reason": "critical condition escalation",
                    })
                    self.support_requests = self.support_requests[-6:]
                    self.communicate(
                        support.name,
                        f"support link established for {critical['id']}",
                    )

        # Broadcast the most recent fleet decision.
        if reason != "startup":
            self.communicate("AI-CENTER", self.fleet_decision)

        self.resolve_route_conflicts()

    # ---------------------------------------------------------
    # AI TASK ALLOCATION
    # ---------------------------------------------------------

    def assign_tasks(self, reason="manual"):
        detected_survivors = [
            survivor
            for survivor in self.survivors
            if survivor["detected"] and not survivor["reached"]
        ]

        if not detected_survivors:
            for robot in self.robots:
                if robot.pos == robot.start:
                    robot.target = robot.start
                    robot.status = "STANDBY"
                    robot.communication = "STANDBY"
            self.ai_last_decision = "No detected survivors requiring assignment"
            if reason != "startup":
                self.log("AI WAITING: NO DETECTED SURVIVORS")
            return

        for survivor in self.survivors:
            if not survivor["reached"]:
                survivor["assigned_robot"] = None

        for robot in self.robots:
            if robot.pos != robot.target and self.running:
                continue
            if robot.pos == robot.target:
                robot.target = robot.pos
            if not self.running:
                robot.status = "STANDBY"

        available = [
            robot for robot in self.robots
            if robot not in [
                self.robot_for_survivor(s)
                for s in self.survivors
                if s["reached"]
            ]
        ]

        ordered = sorted(
            detected_survivors,
            key=lambda s: s["urgency_score"],
            reverse=True,
        )

        decisions = []

        for survivor in ordered:
            if not available:
                break

            candidates = []
            for robot in available:
                route = self.astar(robot.pos, survivor["pos"])
                if not route:
                    continue

                score = self.disaster_response_score(robot, survivor, route)
                hazard_steps = sum(point in self.hazards for point in route)
                candidates.append((score, robot, route, hazard_steps))

            if not candidates:
                continue

            candidates.sort(key=lambda item: item[0], reverse=True)
            score, robot, route, hazard_steps = candidates[0]

            robot.target = survivor["pos"]
            robot.path = route
            robot.path_index = 0
            robot.status = "EN ROUTE" if self.running else "ASSIGNED"
            robot.communication = "TASK ACCEPTED"
            survivor["assigned_robot"] = robot.name
            available.remove(robot)
            decisions.append(f"{robot.name} -> {survivor['id']}")

        if decisions:
            self.ai_last_decision = " | ".join(decisions)
            if reason == "drone":
                self.log("AI ADAPTIVE RESPONSE: " + self.ai_last_decision)
            elif reason in {"manual", "condition"}:
                self.log("AI REALLOCATION: " + self.ai_last_decision)
        else:
            self.ai_last_decision = "Detected targets found, but no safe robot assignment"
            self.log("AI ALERT: NO SAFE ROBOT ASSIGNMENT")

    def robot_for_survivor(self, survivor):
        name = survivor.get("assigned_robot")
        if not name:
            return None
        for robot in self.robots:
            if robot.name == name:
                return robot
        return None

    # ---------------------------------------------------------
    # ROUTING
    # ---------------------------------------------------------

    def prepare_routes(self):
        for robot in self.robots:
            if robot.target == robot.pos:
                robot.path = [robot.pos]
                robot.path_index = 0
                continue

            robot.path = self.astar(robot.pos, robot.target)
            robot.path_index = 0
            if not robot.path:
                robot.status = "NO SAFE ROUTE"
        self.reserve_routes()

    def manhattan(self, a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def neighbors(self, point):
        x, y = point
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            next_point = (x + dx, y + dy)
            if (
                0 <= next_point[0] < COLS
                and 0 <= next_point[1] < ROWS
                and next_point not in self.obstacles
            ):
                yield next_point

    def astar(self, start, goal, blocked=None):
        blocked = blocked or set()
        queue = [(0, start)]
        came_from = {}
        cost = {start: 0}

        while queue:
            _, current = heapq.heappop(queue)
            if current == goal:
                path = [current]
                while current in came_from:
                    current = came_from[current]
                    path.append(current)
                return path[::-1]

            for next_point in self.neighbors(current):
                if next_point in blocked and next_point != goal:
                    continue

                new_cost = cost[current] + 1
                if new_cost < cost.get(next_point, 10**9):
                    cost[next_point] = new_cost
                    came_from[next_point] = current
                    heuristic = self.manhattan(next_point, goal)
                    hazard_penalty = 8 if next_point in self.hazards else 0
                    coordination_penalty = 5 if next_point in blocked else 0
                    heapq.heappush(
                        queue,
                        (
                            new_cost + heuristic + hazard_penalty + coordination_penalty,
                            next_point,
                        ),
                    )
        return []

    # ---------------------------------------------------------
    # DYNAMIC SURVIVOR INTELLIGENCE
    # ---------------------------------------------------------

    def update_survivor_conditions(self, now):
        if not self.running:
            return

        changed = False
        for survivor in self.survivors:
            if survivor["reached"] or not survivor["detected"]:
                continue

            if now - survivor["last_condition_update"] < 4.0:
                continue

            survivor["last_condition_update"] = now
            old_score = survivor["urgency_score"]

            if survivor["severity"] == "CRITICAL":
                increase = 8
            elif survivor["severity"] == "HIGH":
                increase = 6
            else:
                increase = 3

            survivor["urgency_score"] = min(100, old_score + increase)

            if survivor["urgency_score"] >= 90:
                survivor["condition"] = "CRITICAL"
                survivor["treatment_required"] = True
            elif survivor["urgency_score"] >= 70:
                survivor["condition"] = "SERIOUS"
                survivor["treatment_required"] = True
            else:
                survivor["condition"] = "STABLE"

            self.log(
                f"PATIENT UPDATE: {survivor['id']} "
                f"{survivor['condition']} "
                f"({survivor['urgency_score']}/100)"
            )
            changed = True

        if changed:
            self.assign_tasks(reason="condition")
            self.prepare_routes()
            self.coordinate_fleet(reason="condition escalation")
            self.last_ai_replan = now

    # ---------------------------------------------------------
    # ACTIONS
    # ---------------------------------------------------------

    def action(self, action):
        if action == "mission":
            self.running = not self.running
            if self.running:
                if self.mission_start_time is None:
                    self.mission_start_time = time.time()
                    self.mission_end_time = None
                    self.record_timeline("mission_start", "MISSION STARTED")
                else:
                    self.record_timeline("mission_resume", "MISSION RESUMED")
                self.assign_tasks(reason="manual")
                self.prepare_routes()
                self.coordinate_fleet(reason="deployment")
                for robot in self.robots:
                    if robot.pos != robot.target:
                        robot.status = "EN ROUTE"
                self.log("ROBOT FLEET DEPLOYED")
            else:
                self.mission_end_time = time.time() if self.mission_start_time is not None else None
                self.record_timeline("mission_pause", "MISSION PAUSED")
                for robot in self.robots:
                    if robot.pos != robot.target:
                        robot.status = "PAUSED"
                self.log("MISSION PAUSED")

        elif action == "drone":
            self.drone["active"] = not self.drone["active"]
            self.log(
                "RECON DRONE DEPLOYED"
                if self.drone["active"]
                else "RECON DRONE PAUSED"
            )

        elif action == "vision":
            self.run_vision_scan(force=True)

        elif action == "ai":
            self.assign_tasks(reason="manual")
            self.prepare_routes()
            self.coordinate_fleet(reason="manual AI request")

        elif action == "reset":
            self.reset()

        elif action == "stress_test":
            self.stress_test()

        elif action in {"Earthquake", "Flood", "Fire", "Landslide"}:
            self.disaster = action
            self.reset()

        return self.state()

    # ---------------------------------------------------------
    # DRONE PERCEPTION
    # ---------------------------------------------------------

    def run_vision_scan(self, force=False):
        self.vision_active = True
        if force:
            for survivor in self.survivors:
                survivor["detected"] = True
                self.drone["detections"].add(survivor["pos"])

            self.log("COMPUTER VISION: 3 SURVIVORS DETECTED")
            self.assign_tasks(reason="drone")
            self.prepare_routes()
            self.coordinate_fleet(reason="detection")
            self.last_ai_replan = time.time()

    def drone_scan_step(self):
        if not self.drone["active"]:
            return

        x = self.drone["x"]
        y = self.drone["y"]
        newly_detected = []

        for dx in range(-4, 5):
            for dy in range(-4, 5):
                if dx * dx + dy * dy > 20:
                    continue
                nx = x + dx
                ny = y + dy
                if 0 <= nx < COLS and 0 <= ny < ROWS:
                    self.drone["scanned"].add((nx, ny))

        self.drone["scan_progress"] = min(
            100,
            int(len(self.drone["scanned"]) / float(COLS * ROWS) * 100),
        )

        for survivor in self.survivors:
            if self.manhattan((x, y), survivor["pos"]) <= 5:
                if not survivor["detected"]:
                    survivor["detected"] = True
                    self.drone["detections"].add(survivor["pos"])
                    newly_detected.append(survivor["id"])

        if newly_detected:
            self.vision_active = True
            self.log("DRONE DETECTED: " + ", ".join(newly_detected))
            self.assign_tasks(reason="drone")
            self.prepare_routes()
            self.coordinate_fleet(reason="new detection")

        x += 1
        if x >= COLS - 2:
            x = 1
            y += 1
            if y >= ROWS - 2:
                y = 1
                self.log("RECON SWEEP COMPLETE")

        self.drone["x"] = x
        self.drone["y"] = y

    # ---------------------------------------------------------
    # DYNAMIC HAZARD RESPONSE
    # ---------------------------------------------------------

    def hazard_near(self, point, radius=1):
        return any(
            abs(point[0] - hazard[0]) <= radius
            and abs(point[1] - hazard[1]) <= radius
            for hazard in self.hazards
        )

    def reroute_robot(self, robot, reason="hazard"):
        if robot.pos == robot.target:
            return False

        blocked = set()
        for other in self.robots:
            if other is not robot:
                blocked.update(other.reserved_cells[:4])

        route = self.astar(robot.pos, robot.target, blocked=blocked)
        if not route:
            route = self.astar(robot.pos, robot.target)

        if not route:
            robot.status = "NO SAFE ROUTE"
            self.ai_last_decision = f"{robot.name}: no safe route available"
            self.log(f"AI ALERT: {robot.name} NO SAFE ROUTE")
            return False

        robot.path = route
        robot.path_index = 0
        robot.status = "EN ROUTE" if self.running else "ASSIGNED"
        self.hazard_alerts += 1
        self.analytics["replans"] += 1
        self.ai_last_decision = f"REROUTE {robot.name}: {reason} avoidance active"
        self.log(f"AI REROUTE: {robot.name} avoiding {reason}")
        self.reserve_routes()
        return True

    def evaluate_robot_safety(self, robot):
        if robot.pos == robot.target or not robot.path:
            return

        look_ahead = robot.path[robot.path_index + 1: robot.path_index + 7]
        dangerous = any(point in self.hazards for point in look_ahead)
        if dangerous:
            self.reroute_robot(robot, reason="upcoming hazard")

    # ---------------------------------------------------------
    # LIVE MISSION UPDATE
    # ---------------------------------------------------------

    def update(self):
        self.drone_scan_step()
        now = time.time()
        self.update_survivor_conditions(now)

        if not self.running:
            return

        for robot in self.robots:
            self.evaluate_robot_safety(robot)
            if robot.pos in self.hazards and robot.pos != robot.target:
                robot.status = "HAZARD ZONE"
                self.reroute_robot(robot, reason="active hazard")

        if (
            self.drone["active"]
            and self.drone["detections"]
            and now - self.last_ai_replan > 1.5
        ):
            self.assign_tasks(reason="drone")
            self.prepare_routes()
            self.coordinate_fleet(reason="recon update")
            self.last_ai_replan = now

        # Periodic fleet synchronization keeps route reservations fresh.
        if now - self.last_coordination > 0.8:
            self.coordinate_fleet(reason="sync")

        for robot in self.robots:
            if robot.pos == robot.target:
                if robot.target != robot.start:
                    robot.status = "TARGET REACHED"
                    robot.communication = "TARGET REACHED"

                for survivor in self.survivors:
                    if survivor["pos"] == robot.target and not survivor["reached"]:
                        survivor["reached"] = True
                        robot.mission_count += 1
                        self.analytics["rescues"] += 1
                        self.record_timeline(
                            "rescue",
                            f"{robot.name} reached {survivor['id']}",
                            robot=robot.name,
                            survivor=survivor["id"],
                        )
                        survivor["assigned_robot"] = robot.name
                        survivor["support_robot"] = None
                        self.log(f"{robot.name} reached {survivor['id']}")
                        self.communicate(
                            robot.name,
                            f"target secured; {survivor['id']} rescued",
                        )
                continue

            if (
                not robot.path
                or robot.path_index >= len(robot.path)
                or robot.path[-1] != robot.target
            ):
                robot.path = self.astar(robot.pos, robot.target)
                robot.path_index = 0

            if now - robot.last_move >= 0.055 and robot.path_index < len(robot.path) - 1:
                robot.last_move = now
                robot.path_index += 1
                robot.pos = robot.path[robot.path_index]
                self.analytics["robot_moves"] += 1
                robot.communication = "NAVIGATING"

                if robot.pos in self.hazards:
                    robot.status = "HAZARD ZONE"
                else:
                    robot.status = "EN ROUTE"

            if robot.pos == robot.target:
                robot.status = "TARGET REACHED"

        self.reserve_routes()

        if all(survivor["reached"] for survivor in self.survivors):
            if not self.mission_complete:
                self.mission_complete = True
                self.running = False
                self.mission_end_time = time.time()
                self.record_timeline("mission_success", "MISSION SUCCESSFUL - ALL SURVIVORS REACHED")
                for robot in self.robots:
                    robot.communication = "MISSION COMPLETE"
                self.log("MISSION SUCCESSFUL - ALL SURVIVORS REACHED")


    # ---------------------------------------------------------
    # DEMO / STRESS TEST
    # ---------------------------------------------------------

    def stress_test(self):
        """Run a controlled, clearly labelled V10 resilience demonstration."""
        if self.mission_complete:
            self.reset()

        for survivor in self.survivors:
            survivor["detected"] = True
            survivor["last_condition_update"] = time.time()
        self.vision_active = True
        self.assign_tasks(reason="drill")
        self.prepare_routes()

        if self.mission_start_time is None:
            self.mission_start_time = time.time()
        self.mission_end_time = None
        self.running = True
        self.mission_complete = False

        # 1) Inject hazards after routing is prepared. The normal safety
        # evaluator will therefore be forced to demonstrate a real reroute.
        injected = 0
        for robot in self.robots:
            upcoming = robot.path[robot.path_index + 2: robot.path_index + 6]
            if not upcoming:
                continue
            point = upcoming[0]
            if point != robot.target and point not in self.obstacles:
                self.hazards.add(point)
                self.dynamic_hazards.add(point)
                injected += 1

        self.record_timeline(
            "drill",
            f"DEMO DRILL: {injected} controlled hazard(s) injected"
        )
        self.log("AI STRESS TEST: HAZARD AVOIDANCE SCENARIO")

        # Trigger the actual V4/V5 safety evaluator before returning state.
        for robot in self.robots:
            self.evaluate_robot_safety(robot)

        # 2) Create a temporary, explicit reservation collision. This is a
        # controlled coordination drill, so the timeline says DEMO DRILL.
        moving = [r for r in self.robots if len(r.path) > r.path_index + 2]
        if len(moving) >= 2:
            first, second = moving[0], moving[1]
            shared = first.path[first.path_index + 1]
            first.reserved_cells = [shared]
            second.reserved_cells = [shared]

            self.record_timeline(
                "drill",
                f"DEMO DRILL: reservation conflict {first.name} ↔ {second.name}"
            )
            self.analytics["route_conflicts_resolved"] += 1
            self.route_conflicts += 1

            # Urgency determines right-of-way. The lower-priority unit gets
            # a fresh route that avoids the higher-priority reservation.
            first_survivor = self.survivor_for_robot(first)
            second_survivor = self.survivor_for_robot(second)
            first_score = first_survivor["urgency_score"] if first_survivor else 0
            second_score = second_survivor["urgency_score"] if second_survivor else 0
            higher, lower = (first, second) if first_score >= second_score else (second, first)

            alternate = self.astar(
                lower.pos,
                lower.target,
                blocked=set(higher.reserved_cells),
            )
            if alternate and alternate != lower.path:
                lower.path = alternate
                lower.path_index = 0
                lower.communication = f"YIELDING TO {higher.name}"
                higher.communication = "RIGHT OF WAY"
                self.communicate(
                    lower.name,
                    f"route conflict resolved; yielding to {higher.name}",
                )
                self.record_timeline(
                    "coordination",
                    f"DEMO DRILL: {lower.name} yielded to {higher.name}; conflict resolved",
                )
                self.ai_last_decision = (
                    f"CONFLICT RESOLVED: {higher.name} priority over {lower.name}"
                )
            else:
                self.communicate(
                    higher.name,
                    f"holding priority; {lower.name} route unchanged",
                )
                self.record_timeline(
                    "coordination",
                    f"DEMO DRILL: conflict resolved by priority hold ({higher.name})",
                )
                self.ai_last_decision = (
                    f"CONFLICT RESOLVED: {higher.name} priority hold"
                )
            self.reserve_routes()

        self.coordinate_fleet(reason="stress test")
        self.last_ai_replan = time.time()
        return self.state()

    # ---------------------------------------------------------
    # STATE FOR WEB APP
    # ---------------------------------------------------------

    def state(self):
        self.update()

        return {
            "disaster": self.disaster,
            "disaster_profile": self.profile,
            "hazard_type": self.profile["hazard_type"],
            "hazard_penalty": self.profile["hazard_penalty"],
            "running": self.running,
            "mission_complete": self.mission_complete,
            "robots": [
                {
                    "name": robot.name,
                    "role": robot.role,
                    "x": robot.pos[0],
                    "y": robot.pos[1],
                    "target": [robot.target[0], robot.target[1]],
                    "status": robot.status,
                    "color": robot.color,
                    "missions": robot.mission_count,
                    "communication": robot.communication,
                    "support_request": robot.support_request,
                    "assisting": robot.assisting,
                    "reserved_cells": [[x, y] for x, y in robot.reserved_cells],
                    "path": [[x, y] for x, y in robot.path[robot.path_index + 1:]],
                }
                for robot in self.robots
            ],
            "survivors": [
                {
                    "id": survivor["id"],
                    "x": survivor["pos"][0],
                    "y": survivor["pos"][1],
                    "severity": survivor["severity"],
                    "reached": survivor["reached"],
                    "detected": survivor["detected"],
                    "assigned_robot": survivor["assigned_robot"],
                    "support_robot": survivor["support_robot"],
                    "condition": survivor["condition"],
                    "urgency_score": survivor["urgency_score"],
                    "treatment_required": survivor["treatment_required"],
                }
                for survivor in self.survivors
            ],
            "obstacles": [[x, y] for x, y in self.obstacles],
            "hazards": [[x, y] for x, y in self.hazards],
            "drone": {
                "x": self.drone["x"],
                "y": self.drone["y"],
                "active": self.drone["active"],
                "scanned": [[x, y] for x, y in self.drone["scanned"]],
                "scan_progress": self.drone["scan_progress"],
                "detections": [[x, y] for x, y in self.drone["detections"]],
            },
            "vision": self.vision_active,
            "mapped": len(self.drone["scanned"]),
            "hazard_count": len(self.hazards),
            "ai_mode": self.ai_mode,
            "ai_strategy": self.disaster_message(),
            "ai_last_decision": self.ai_last_decision,
            "hazard_alerts": self.hazard_alerts,
            "dynamic_hazards": len(self.dynamic_hazards),
            "analytics": self.analytics_snapshot(),
            "timeline": list(self.timeline),
            "coordination": {
                "active": self.coordination_active,
                "cycles": self.coordination_cycles,
                "route_conflicts": self.route_conflicts,
                "support_requests": self.support_requests,
                "fleet_decision": self.fleet_decision,
                "communications": self.communication_log,
            },
            "events": self.events,
        }
