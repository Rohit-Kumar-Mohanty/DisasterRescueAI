# DisasterRescueAI V8

Browser-based multi-robot disaster-response simulation for local demonstration.

## V8 capabilities
- Live browser command center
- Rohit Kumar Mohanty identity + live clock
- Earthquake, Flood, Fire, and Landslide modes
- Recon drone mapping and survivor detection
- Explainable AI task allocation
- Dynamic survivor condition / urgency updates
- Hazard-aware A* rerouting
- Multi-robot coordination and communication layer
- Critical-patient support links
- Route reservation and conflict-aware navigation
- Fleet synchronization cycles
- Mission log and AI decision dashboard

## Run

```cmd
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Demo flow
1. Select a disaster.
2. Start Recon Drone.
3. Wait for survivor detection or use Vision Scan.
4. Deploy the fleet.
5. Watch survivor urgency, robot communications, support links, route reservations, and mission log.

## Important
This is a local simulation/prototype. It does not control physical robots or provide real-world emergency guidance.


## V9 Mission Analytics & Replay

V9 adds a mission telemetry layer to the V8 coordination system. The browser now exposes mission elapsed time, AI decision count, hazard avoidances, coordination events, route conflicts, robot movement count, rescue count, and a rolling mission timeline. The timeline acts as a lightweight replay record of the autonomous operation.


## V10 Stress Test

Use **⚡ Stress Test** (or press `T`) to run a controlled demonstration of the V9 analytics layer. It injects a small number of temporary hazards ahead of active robots and creates a temporary shared reservation so the coordination engine can demonstrate hazard avoidance and conflict resolution. The timeline explicitly labels these as `DEMO DRILL` events.


### V10 test procedure

Use **⚡ Stress Test** or press `T`. The drill injects controlled hazards ahead of active robots and creates a temporary reservation collision. Both are explicitly labelled `DEMO DRILL` in the timeline so the demonstration is transparent. Normal missions remain unchanged.
